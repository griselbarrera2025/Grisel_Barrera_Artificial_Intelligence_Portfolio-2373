# Neural Network Zoo

## 📌 Problem Statement
This project explores a variety of neural network architectures to understand their unique strengths, weaknesses, and use cases in deep learning.

## 🛠 Approach & Methodology
- Implemented multiple architectures including CNN, RNN, LSTM, and Transformer-based models.
- Used TensorFlow and PyTorch frameworks for side-by-side comparison.
- Trained on benchmark datasets to evaluate performance.

## 📊 Results & Evaluation
- CNN performed best for image classification with 94% accuracy.
- LSTM showed strong performance for sequential text prediction.
- Transformer-based architecture excelled in contextual understanding tasks.
- Detailed charts available in the `results/` folder.

## 📚 Learning Outcomes
- Comparative analysis of architectures.
- Improved understanding of model selection for different problem types.
- Hands-on practice with TensorFlow and PyTorch implementations.

## ⚙ Requirements
```bash
pip install -r ../../requirements.txt
```

## 📂 Dataset
- CIFAR-10 for image classification
- IMDB dataset for text sentiment analysis

## ▶ How to Run
1. Navigate to this directory:
```bash
cd DeepLearning-ITAI2376/NeuralNetworkZoo
```
2. Run:
```bash
python model.py
```
3. View results in the `results/` folder.
