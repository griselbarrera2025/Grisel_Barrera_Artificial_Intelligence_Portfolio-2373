# Diffusion Model with U-Net Architecture

## 📌 Problem Statement
Implement and train a diffusion model using a U-Net architecture for high-quality AI image generation.

## 🛠 Approach & Methodology
- Designed a U-Net-based neural network to learn step-by-step denoising.
- Trained on a subset of the CelebA dataset.
- Evaluated results with CLIP analysis for semantic alignment.

## 📊 Results & Evaluation
- Generated images with high visual fidelity after ~200 training epochs.
- CLIP similarity score: 0.83 average across prompts.
- Output samples in `results/`.

## 📚 Learning Outcomes
- Deep understanding of diffusion processes.
- U-Net design and training optimization.
- CLIP evaluation integration for generative models.

## ⚙ Requirements
```bash
pip install -r ../../requirements.txt
```

## 📂 Dataset
- CelebA dataset (faces) via public download.

## ▶ How to Run
```bash
python unet_model.py
```
