# Text Processing Project

## 📌 Problem Statement
Demonstrate the complete NLP pipeline from raw text to vector representation.

## 🛠 Approach & Methodology
- Text cleaning and normalization.
- Tokenization and stop word removal.
- Stemming and lemmatization.
- POS tagging.
- Vectorization using Bag-of-Words, TF-IDF, and Word2Vec embeddings.

## 📊 Results & Evaluation
- Observed performance differences between vectorization methods.
- TF-IDF improved classification accuracy over Bag-of-Words.
- Word embeddings provided better semantic similarity scores.

## 📚 Learning Outcomes
- Hands-on application of multiple NLP preprocessing techniques.
- Understanding trade-offs between vectorization methods.

## ⚙ Requirements
```bash
pip install -r ../../requirements.txt
```

## ▶ How to Run
1. Open `preprocessing.ipynb`.
2. Run all cells to see the transformation pipeline in action.
