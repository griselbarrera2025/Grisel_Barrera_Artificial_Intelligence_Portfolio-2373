# NewsBot Intelligence 2.0

## 📌 Problem Statement
An advanced NLP news classification and analysis system capable of deep text understanding, multilingual processing, and intelligent content generation.

## 🛠 Approach & Methodology
- Preprocessing: tokenization, stop word removal, lemmatization.
- Feature extraction: TF-IDF and word embeddings.
- Classification models: Logistic Regression, Random Forest, and BERT fine-tuning.
- Topic modeling: LDA and NMF for trend analysis.
- Multilingual support: integrated Google Translate API.

## 📊 Results & Evaluation
- Logistic Regression accuracy: 92% on BBC dataset.
- BERT fine-tuning improved F1-score for smaller classes.
- Topics discovered by LDA aligned with actual category trends.
- Visualizations in `outputs/`.

## 📚 Learning Outcomes
- Model comparison for NLP tasks.
- Deployment-ready architecture for news classification.
- Integration of classical ML and transformer-based NLP.

## ⚙ Requirements
```bash
pip install -r ../../requirements.txt
```

## 📂 Dataset
- BBC News Classification Dataset from Kaggle.

## ▶ How to Run
1. Open `preprocessing.ipynb` in Jupyter/Colab.
2. Run preprocessing and model training cells.
3. View results in the `outputs/` folder.
