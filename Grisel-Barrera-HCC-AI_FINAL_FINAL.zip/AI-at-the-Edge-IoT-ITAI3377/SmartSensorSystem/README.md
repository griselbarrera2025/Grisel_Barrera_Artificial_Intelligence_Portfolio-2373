# Smart IoT Sensor Alert System

## 📌 Problem Statement
Develop an AI-powered IoT system that monitors environmental data and sends alerts when anomalies are detected.

## 🛠 Approach & Methodology
- IoT device simulated in Python for temperature, humidity, and air quality.
- Machine learning anomaly detection using Isolation Forest.
- Real-time alerts via console output (future work: SMS/Email integration).

## 📊 Results & Evaluation
- Successfully detected anomalies in simulated data streams.
- Low false positive rate (<5%) with tuned model parameters.

## 📚 Learning Outcomes
- Applied AI for edge devices.
- Understanding anomaly detection algorithms in IoT contexts.

## ⚙ Requirements
```bash
pip install -r ../../requirements.txt
```

## ▶ How to Run
```bash
python iot_script.py
```
