# Text Representation — BoW, TF-IDF, Word Embeddings

## 🧠 Problem Statement
Compare multiple text vectorization strategies for downstream ML tasks.

## 🔧 Approach & Methodology
- **BoW** with `CountVectorizer`
- **TF-IDF** with `TfidfVectorizer`
- **Embeddings** with pre-trained vectors (e.g., GloVe via `gensim`, optional)

## 📈 Results & Evaluation
- TF-IDF improves over BoW by weighting informative terms
- Embeddings capture semantic similarity; helpful for generalization

## ✅ Learning Outcomes
- When to choose sparse vs. dense features
- Vocabulary size/shape impacts on models

## 📦 Requirements
- Root `requirements.txt`
- Optional: `gensim` for embeddings (uncomment in `requirements.txt` or install separately)

## ▶️ How to Run
Open `tfidf_bow_embeddings.ipynb`.  
Use `sample_data/` for inputs; artifacts saved to `outputs/`.
