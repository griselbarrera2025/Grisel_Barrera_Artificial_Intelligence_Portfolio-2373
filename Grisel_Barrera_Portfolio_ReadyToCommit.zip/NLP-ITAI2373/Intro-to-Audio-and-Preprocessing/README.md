# Intro to Audio & Preprocessing (MFCCs)

## 🧠 Problem Statement
Prepare raw audio for ML by applying standard preprocessing and extracting MFCCs.

## 🔧 Approach & Methodology
- Load/normalize audio, trim silence
- Extract MFCCs and basic spectral features
- Visualize waveforms/spectrograms

## 📈 Results & Evaluation
- Feature plots show impact of preprocessing
- Ready-to-use features for downstream classification tasks

## ✅ Learning Outcomes
- Fundamentals of audio pipelines and MFCCs

## 📦 Requirements
- Root `requirements.txt`
- Optional: `librosa` for feature extraction (install if used)

## ▶️ How to Run
Open `audio_preprocessing.ipynb`.  
Place short WAV files in `sample_audio/`. Generated plots/features in `outputs/`.
