# Syntax Parsing & Semantic Analysis

## 🧠 Problem Statement
Use linguistic structure to enrich text understanding (POS, dependencies, NER).

## 🔧 Approach & Methodology
- spaCy pipeline: POS tagging, dependency parsing, NER
- Inspect token attributes: `.lemma_`, `.dep_`, `.head`, `.ent_type_`

## 📈 Results & Evaluation
- Example parses and entity tables stored in `outputs/`

## ✅ Learning Outcomes
- Practical use of structural signals for NLP tasks

## 📦 Requirements
- Root `requirements.txt`
- Download spaCy model:
```
python -m spacy download en_core_web_sm
```

## ▶️ How to Run
```
python syntax_semantic.py
```
Adjust input/output paths as needed.
