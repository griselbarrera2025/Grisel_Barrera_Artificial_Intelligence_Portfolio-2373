# BBC News Classification — Text Processing Pipeline

## 🧠 Problem Statement
Classify BBC news articles into categories (business, entertainment, politics, sport, tech).

## 🔧 Approach & Methodology
- Text cleaning: lowercasing, punctuation removal, stopword filtering, lemmatization
- Feature extraction: TF-IDF
- Models: Logistic Regression, Random Forest, Naive Bayes
- Evaluation: accuracy/F1, confusion matrix

## 📈 Results & Evaluation
- Best baseline: Logistic Regression (~0.91 accuracy in prior runs)
- Confusion matrix shows clear separation between categories like sport vs. tech

## ✅ Learning Outcomes
- Built a reproducible preprocessing pipeline
- Understood feature extraction trade-offs for classic ML classifiers

## 📦 Requirements
- Root `requirements.txt`

## ▶️ How to Run
Open `preprocessing.ipynb` and run cells top-to-bottom.  
Place example CSVs in `sample_data/` (if used). Outputs are saved in `outputs/`.
