# Sentiment & Emotion Analysis

## 🧠 Problem Statement
Detect both sentiment polarity and fine-grained emotions from text.

## 🔧 Approach & Methodology
- Vectorization with BoW/TF-IDF
- Baseline classifier: Logistic Regression
- Optional: multi-label setup if using multiple emotion classes

## 📈 Results & Evaluation
- Report accuracy/F1; confusion matrices saved in `results/`

## ✅ Learning Outcomes
- Designing labels for emotions vs. sentiment
- Feature engineering vs. model capacity trade-offs

## 📦 Requirements
- Root `requirements.txt`

## ▶️ How to Run
```
python sentiment_emotion.py
```
If a dataset is required, place a small CSV in `sample_data/` and update the script’s path.
