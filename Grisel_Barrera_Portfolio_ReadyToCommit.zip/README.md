# Grisel Barrera — Applied AI & Robotics Portfolio (HCC)

**Program:** Applied AI & Robotics, Houston Community College  
**Location:** Houston, TX  
**Email:** griselbarrera2016@gmail.com  
**LinkedIn:** https://www.linkedin.com/in/GriselBarrera

---

## 📄 Overview
This portfolio showcases hands-on projects completed during the Applied AI & Robotics program at Houston Community College.  
Skills demonstrated include: deep learning, natural language processing, computer vision, audio analysis, IoT/edge AI, and conversational AI.

---

## 📚 Courses & Skills
- **Deep Learning (ITAI 2376)** – CNNs, RNNs, GANs, U-Net, optimization, diffusion models  
- **Natural Language Processing (ITAI 2373)** – Preprocessing, sentiment/emotion analysis, NER, POS tagging, topic modeling  
- **AI at the Edge / IoT (ITAI 3377)** – Embedded AI systems, sensor data processing, low-latency models  
- **Conversational AI** – Intent classification, dialogue systems, LLM integration  

---

## 📌 Featured Projects
- [**BBC News Classification (NLP)**](NLP-ITAI2373/Text-Processing-Project/)  
  Multi-class text classification using TF-IDF and classic ML models.

- [**Text Representation: BoW, TF-IDF, Word Embeddings**](NLP-ITAI2373/Text-Representation/)  
  Comparative analysis of vectorization techniques for NLP.

- [**Intro to Audio & Preprocessing (MFCCs)**](NLP-ITAI2373/Intro-to-Audio-and-Preprocessing/)  
  Audio loading, cleaning, and feature extraction for ML.

- [**Sentiment & Emotion Analysis**](NLP-ITAI2373/Sentiment-and-Emotion-Analysis/)  
  Combined sentiment polarity and fine-grained emotion classification.

- [**Syntax Parsing & Semantic Analysis**](NLP-ITAI2373/Syntax-Parsing-and-Semantic-Analysis/)  
  POS tagging, dependency parsing, and entity extraction with spaCy.

- [**Smart IoT Sensor Alert System**](AI-at-the-Edge-IoT-ITAI3377/SmartSensorSystem/)  
  Lightweight edge AI model for real-time sensor-based alerts.

---

## ▶️ How to Run
1. Clone the repository:
   ```bash
   git clone https://github.com/YOUR-USERNAME/Grisel-Barrera-HCC-AI.git
   cd Grisel-Barrera-HCC-AI
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Navigate to a project folder and follow the instructions in its `README.md`.

---

## 📦 Requirements
See [`requirements.txt`](requirements.txt) for core dependencies.  
Project-specific dependencies are listed inside each project folder’s README.

---
