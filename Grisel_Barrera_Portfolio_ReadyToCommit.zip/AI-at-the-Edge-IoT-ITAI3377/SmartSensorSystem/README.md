# Smart IoT Sensor Alert System

## 🧠 Problem Statement
Detect anomalous or critical states from sensor streams on edge devices with minimal latency.

## 🔧 Approach & Methodology
- Load sensor CSV, compute simple features
- Thresholding or lightweight ML for alerting
- Considerations for on-device constraints

## 📈 Results & Evaluation
- Precision/recall of alerts; note latency in a simple benchmark

## ✅ Learning Outcomes
- Practicalities of edge ML design and deployment constraints

## 📦 Requirements
- Root `requirements.txt`

## ▶️ How to Run
```
python iot_model.py
```
Put example CSVs under `sensor_data/`; adapt script args for file paths.
